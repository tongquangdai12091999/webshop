function Contact(){
    return (
        <div className="Contact">
<h1> Trang Contact</h1>
        </div>
    )
}
export default Contact;