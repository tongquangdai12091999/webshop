function News(){
    return (
        <div className="News">
<h1> Trang News</h1>
        </div>
    )
}
export default News;