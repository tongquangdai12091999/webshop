function Home(){
    return (
        <div className="Home">
<h1> Trang Home</h1>
        </div>
    )
}
export default Home;